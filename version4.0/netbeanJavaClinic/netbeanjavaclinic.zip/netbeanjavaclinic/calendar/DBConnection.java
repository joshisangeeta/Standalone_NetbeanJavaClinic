package netbeanjavaclinic.calendar;



import java.sql.Connection;

public class DBConnection {

	public static Connection get() {
		// TODO Auto-generated method stub
		return null;
	}

}
